// DESARROLLAR UN PROGRAMA DE “INSTRUCCIÓN ASISTIDA POR COMPUTADORA” EN LENGUAJE JAVA

import java.util.InputMismatchException;
import java.util.Scanner;

public class InstruccionAsistida {

  public static void main(String[] args) {
      try (Scanner sc = new Scanner(System.in)) {
          int nivel, tipo, correctas, total;
          int num1, num2, resultado;
          int[] niveles = {10, 100, 1000};
          char[] operaciones = {'+', '-', '*', '/'};
          String[] mensajesPositivos = {"¡Muy bien!", "¡Excelente!", "¡Buen trabajo!", "¡Sigue así!"};
          String[] mensajesNegativos = {"No. Por favor intenta de nuevo.", "Incorrecto. Intenta una vez más.", "¡No te rindas!", "No. Sigue intentando."};
          correctas = 0;
          total = 0;
          while (true) {
              System.out.println("╔══════════════════════════════════╗");
              System.out.println("║ Elige el nivel de dificultad:    ║");
              System.out.println("║ 1. Fácil                         ║");
              System.out.println("║ 2. Medio                         ║");
              System.out.println("║ 3. Difícil                       ║");
              System.out.println("╚══════════════════════════════════╝");
              System.out.print("Tu opción: ");
              
              try {
                  nivel = sc.nextInt();
                  if (nivel < 1 || nivel > 3) {
                      throw new InputMismatchException();
                  }
                  
                  System.out.println("╔═════════════════════════╗");
                  System.out.println("║ Elige el tipo de problema aritmético: ║");
                  System.out.println("║ 1. Suma                  ║");
                  System.out.println("║ 2. Resta                 ║");
                  System.out.println("║ 3. Multiplicación        ║");
                  System.out.println("║ 4. División              ║");
                  System.out.println("║ 5. Mezcla aleatoria      ║");
                  System.out.println("╚═════════════════╝");
                  System.out.print("Tu opción: ");
                  
                  tipo = sc.nextInt();
                  if (tipo < 1 || tipo > 5) {
                      throw new InputMismatchException();
                  }
                  
                  num1 = (int) (Math.random() * niveles[nivel - 1] + 1);
                  num2 = (int) (Math.random() * niveles[nivel - 1] + 1);
                  
                  if (tipo == 5) {
                      tipo = (int) (Math.random() * 4 + 1);
                  }
                  
                  switch (tipo) {
                      case 1:
                          resultado = num1 + num2;
                          break;
                      case 2:
                          resultado = num1 - num2;
                          break;
                      case 3:
                          resultado = num1 * num2;
                          break;
                      case 4:
                          resultado = num1 / num2;
                          break;
                      default:
                          resultado = 0;
                          break;
                  }
                  
                  System.out.print("¿Cuánto es " + num1 + " " + operaciones[tipo - 1] + " " + num2 + "? ");
                  
                  int respuesta = sc.nextInt();
                  
                  if (respuesta == resultado) {
                      System.out.println(mensajesPositivos[(int) (Math.random() * 4)]);
                      correctas++;
                  } else {
                      System.out.println(mensajesNegativos[(int) (Math.random() * 4)]);
                  }
                  
                  total++;
                  
                  if (total == 10) {
                      break;
                  }
                  
              } catch (InputMismatchException e) {
                  System.out.println("Opción inválida. Debes ingresar un número entero.");
                  sc.nextLine();
              } catch (ArithmeticException e) {
                  System.out.println("Error aritmético. No se puede dividir por cero.");
              }
              
          }     System.out.println("╔═╗");
          System.out.println("║ Has respondido correctamente a " + correctas + " preguntas de 10. ║");
          if (correctas == 10) {
              System.out.println("║ ¡Felicidades! Has dominado el nivel y el tipo de problema elegidos. ║");
          } else {
              System.out.println("║ Te sugerimos que repases el nivel y el tipo de problema elegidos.   ║");
          }     System.out.println("╚═╝");
      }
    
  }

}
